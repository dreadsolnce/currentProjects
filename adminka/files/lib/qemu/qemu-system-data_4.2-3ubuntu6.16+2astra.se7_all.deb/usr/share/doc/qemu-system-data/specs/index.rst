.. This is the top level page for the 'specs' manual


QEMU System Emulation Guest Hardware Specifications
===================================================


Contents:

.. toctree::
   :maxdepth: 2

   ppc-xive
   ppc-spapr-xive
   acpi_hw_reduced_hotplug
